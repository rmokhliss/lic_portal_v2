// ==============================================================================
// LIC v2 — ListClientsUseCase (Phase 4 étape 4.B)
//
// Read-only, cursor-based pagination (Référentiel §4.15). Le repo gère la
// décode/encode du cursor + détection page suivante via LIMIT+1.
// FTS optionnel via `q` → search_vector @@ plainto_tsquery (ADR 0004).
// ==============================================================================

import { toDTO, type ClientDTO } from "../adapters/postgres/client.mapper";
import type { ClientStatut } from "../domain/client.entity";
import type { ClientRepository, FindClientsPaginatedInput } from "../ports/client.repository";

export interface ListClientsUseCaseInput {
  readonly actif?: boolean;
  readonly statutClient?: ClientStatut | readonly ClientStatut[];
  readonly q?: string;
  /** Phase 20 R-29 — filtres enrichis. */
  readonly codePays?: string;
  readonly accountManager?: string;
  readonly salesResponsable?: string;
  /** Phase 21 R-29 — filtre région (sub-query lic_pays_ref). */
  readonly regionCode?: string;
  /** Phase 21 R-29 — true = clients sans licence ACTIF. */
  readonly sansLicence?: boolean;
  readonly cursor?: string;
  readonly limit?: number;
}

export interface ListClientsUseCaseOutput {
  readonly items: readonly ClientDTO[];
  readonly nextCursor: string | null;
  readonly effectiveLimit: number;
  /** Phase 20 R-29 — total clients matchant les filtres (hors pagination). */
  readonly total: number;
}

export class ListClientsUseCase {
  constructor(private readonly clientRepository: ClientRepository) {}

  async execute(input: ListClientsUseCaseInput = {}): Promise<ListClientsUseCaseOutput> {
    const opts: FindClientsPaginatedInput = {
      ...(input.actif !== undefined ? { actif: input.actif } : {}),
      ...(input.statutClient !== undefined ? { statutClient: input.statutClient } : {}),
      ...(input.q !== undefined ? { q: input.q } : {}),
      ...(input.codePays !== undefined ? { codePays: input.codePays } : {}),
      ...(input.accountManager !== undefined ? { accountManager: input.accountManager } : {}),
      ...(input.salesResponsable !== undefined ? { salesResponsable: input.salesResponsable } : {}),
      ...(input.regionCode !== undefined ? { regionCode: input.regionCode } : {}),
      ...(input.sansLicence !== undefined ? { sansLicence: input.sansLicence } : {}),
      ...(input.cursor !== undefined ? { cursor: input.cursor } : {}),
      ...(input.limit !== undefined ? { limit: input.limit } : {}),
    };

    const result = await this.clientRepository.findPaginated(opts);
    return {
      items: result.items.map(toDTO),
      nextCursor: result.nextCursor,
      effectiveLimit: result.effectiveLimit,
      total: result.total,
    };
  }
}
